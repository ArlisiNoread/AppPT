package com.arlisi.algoritmo;

import java.util.Random;

public class RandomAux extends Random { }
