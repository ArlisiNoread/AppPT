package com.arlisi.apppt

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class PanelResultadosActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_panel_resultados)

        val myIntent = getIntent()
        val recomendaciones: ArrayList<Int> =
            myIntent.getIntegerArrayListExtra("resultados") ?: ArrayList<Int>()

        (findViewById(R.id.textResultados) as TextView).setText("" + recomendaciones)
    }
}